//
//  main.cpp
//  C867
//
//  Created by Josh Kinard on 2/6/22.
//

#include <iostream>

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
